var button_1="";
var button_2="";
var button_3="";
var button_4="";
var button_5="";
var button_6="";
var button_7="";
var button_8="";


// Editable section for Localization - Top Menu Bar Buttons
// Up to eight menu bar buttons can be defined. 
// If a button is not required, remove the button line below

var button_1 = "IC Package Map";
var button_2 = "Glossary";
var button_3 = "Resources";
var button_4 = "Feedback";
var button_5 = "Add Bookmarks";
var button_6 = "View Bookmarks";
var button_7 = "Help";
var button_8 = "FAQs";

// Editable section for Localization - Linear Navigation Buttons

var button_next = "Next";
var button_previous = "Previous";
var button_return = "RETURN";

// Editable section for Localization - Topic Menu Optional Links

var topic_option_title = "Reference Materials";
var topic_option_1 = "UML Quick Start";
var topic_option_2 = "RUP Lite";
var topic_copy = "&copy 2005 IBM Corporation";

//  Editable section for Localization - text for course evaluation links :conclusion and resource pages
var course_eval = "Module Evaluation";

//  Editable section for Localization - Additional Resource link on conclusion page
var addResources = "Additional Resources";


var pop_close = "Close Window";

var help_3a_link1_text = "Internet Explorer (Version 6.0 and later)";
var help_3a_link2_text = "Netscape Navigator (Version 7.0 and later)";
var help_3a_link3_text = "Mozilla Version (1.1 and later)";

var help_4a_link1_text = "Macromedia Flash Player";
var help_4a_link2_text = "Adobe Acrobat Reader";
