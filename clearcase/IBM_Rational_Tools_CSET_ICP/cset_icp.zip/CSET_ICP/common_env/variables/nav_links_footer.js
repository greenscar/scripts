var footer_1_link = "<a href='http://www.ibm.com/ibm/us' target='_blank'>";
var footer_2_link = "<a href='http://www.ibm.com/privacy/us/' target='_blank'>";
var footer_3_link = "<a href='http://www.ibm.com/legal/us/' target='_blank'>";
var footer_4_link = "<a href='common_page/contact.html' target='mainContent'>";
