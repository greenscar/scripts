// common navigation links
var button_4_link;
var footer_2_link;
var footer_2b_link;

var button_1_link = "<a href='../common_env/common_page/coursemap.html' target='mainContent'>";
var button_2_link = "<a href='resources/glossary.html' target='mainContent'>";
var button_3_link = "<a href='resources/resources.html' target='mainContent'>";

var button_5_link = "<a href='#' onClick='addBookmark();return false;' target='mainContent'>";
var button_6_link = "<a href='#' onClick='viewBookmark();return false;' target='mainContent'>";
var button_7_link = "<a href='../common_env/common_page/wbt_help.html' target='mainContent'>";
var button_8_link = "<a href='resources/faqs.html' target='mainContent'>";

//UML Quick Start Guide Linking Variables:
var topic_link_1 = "<a href='../../rational_uml2-0/uml_index.html' target='mainContent'>";
var topic_link_1_path = "../../rational_uml2-0/";
var topic_link_1_alt = "../../../rational_uml2-0/uml_index.html";

var topic_link_2 = "<a href='" + baseLink + "../common_content/rup_lite/rup_lite.html' target='_blank'>";

// set the evaluation for the main browser window environment
if (parent.navBar){
	var evaluationLink_1 = "<a href='" + baseLink + "../common_env/common_page/feedback.html' target='mainContent'>" + course_eval + "</a>";
	var evaluationLink_2 = "<a href='" + baseLink + "../common_env/common_page/feedback.html' target='mainContent'>" + course_eval + "</a>";
}
var help_3a_link1 = "<a href='http://www.microsoft.com/downloads/search.asp?' target='_blank'>";
var help_3a_link2 = "<a href='http://home.netscape.com/computing/download/index.html?cp=hophb2' target='_blank'>";
var help_3a_link3 = "<a href='http://www.mozilla.org/' target='_blank'>";

var help_4a_link1 = "<a href='http://www.macromedia.com/shockwave/download/frameset.fhtml?P1_Prod_Version=ShockwaveFlash' Target='_blank'>";
var help_4a_link2 = "<a href='http://www.adobe.com/products/acrobat/readstep2.html' target='_blank'>";

