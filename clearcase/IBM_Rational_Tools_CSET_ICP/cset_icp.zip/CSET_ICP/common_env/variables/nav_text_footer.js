var footer_1 = "About IBM";
var footer_2 = "Privacy";
var footer_3 = "Terms of use";
var footer_4 = "Contact";
