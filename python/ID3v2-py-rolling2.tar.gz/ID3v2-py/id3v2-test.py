#!/usr/bin/python2
from ID3v2 import *
import sys

action = sys.argv[1]

# Here is an example of reading and dumping an ID3 tag
if action == "read":
    file = ID3v2(sys.argv[2])
    dumpList =  file.dump()
    for x in range(len(dumpList)):
        print dumpList[x]

# Here are some examples of creating frames inside tags.
if action == "set":
    file = ID3v2(sys.argv[2])
    newFrame = {'TAG':'TIT2','text':'Test Title'}
    file.addFrame(newFrame)
    newFrame = {'TAG':'COMM','language':'enu','description':'testcomment','comment':'testing comment tags'}
    file.addFrame(newFrame)
    newFrame = {'TAG':'TRCK','text':'01'}
    file.addFrame(newFrame)
    file.write()

# Here are some examples of deleting frames. pass in the Tag of the frame you
# want to delete
if action == "delete":
    file = ID3v2(sys.argv[3])
    file.delFrame(sys.argv[2])
    file.write()

# Here is an example of the use of the deleteAll call. Don't trust it.
if action == "deleteAll":
    file = ID3v2(sys.argv[2])
    file.deltags()
    file.write()

# Just read in tags, and write them back out
if action == "basic":
    file = ID3v2(sys.argv[2])
    file.write()
