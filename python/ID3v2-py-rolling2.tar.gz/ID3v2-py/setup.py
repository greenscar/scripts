#!/usr/bin/env python

"""Setup script for the ID3v2 module distribution."""

__revision__ = "$Id: setup.py,v 1.1 2000/09/21 22:10:00 ben Exp $"

from distutils.core import setup

setup (# Distribution meta-data
       name = "ID3v2",
       version = "alpha",
       description = "Module for manipulating ID3v2 informational tags on MP3 audio files",
       author = "Robert Sherwood",
       author_email = "foofboy@speakeasy.net",
       url = "http://id3v2-py.sourceforge.net",

       # Description of the modules and packages in the distribution
       py_modules =
       ['ID3v2','ID3v2frames.__init__','ID3v2frames.InvalidFrameError','ID3v2frames.TextInformationFrame','ID3v2frames.albumFrame','ID3v2frames.artistFrame','ID3v2frames.blackBoxFrame','ID3v2frames.commentFrame','ID3v2frames.genreFrame','ID3v2frames.titleFrame','ID3v2frames.trackFrame','ID3v2frames.yearFrame']
      )
