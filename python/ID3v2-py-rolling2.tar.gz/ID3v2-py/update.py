#!/usr/bin/python2
import sys
import os
import string
import glob
import pwd
import grp
from ID3v2 import *
baseDir = '/opt/mp3/'
playlist=open(baseDir+'playlist','w')
for banddir in os.listdir(baseDir):
 if os.path.isdir(baseDir + banddir):
     print banddir
     for albumdir in os.listdir(baseDir + banddir + '/'):
      if os.path.isdir(baseDir + banddir + '/' + albumdir):
          print '    ',albumdir
          for trackfile in glob.glob(baseDir + banddir + '/' + albumdir + '/*.mp3'):
              playlist.write(trackfile+'\n')
              artist = string.replace(banddir,'_',' ')
              artist = artist
              album = string.replace(albumdir,'_',' ')
              album = album
              trackfilename =  os.path.basename(trackfile)
              trackfilename = string.split(trackfilename,'.mp3')[0]
              track = string.split(trackfilename,'-')[0]
              title = string.join(string.split(trackfilename,'-')[1:])
              title = string.replace(title,'_',' ')
              title = title[:29]
              try:
                  print '        '+trackfilename
                  mp3 = ID3v2(trackfile)
                  mp3.addFrame({'TAG':'TIT2','text':title})
                  mp3.addFrame({'TAG':'TRCK','text':track})
                  mp3.addFrame({'TAG':'TALB','text':album})
                  mp3.addFrame({'TAG':'TPE1','text':artist})
                  mp3.write()
                  del mp3
                  pw_id = pwd.getpwnam('www-data')[2]
                  gr_id = grp.getgrnam('www-data')[2]
                  os.chown(trackfile,pw_id,gr_id)
              except InvalidTagError, message:
                  print "Invalid ID3 tag: ", message

playlist.close()
